import { Component } from '@angular/core';
 
@Component({
  selector: 'myapp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export  class AppComponent {
  title = 'CustomerApplication';
}

@Component({})
export class AppComponent1 {
  title = 'CustomerApplication';
}
