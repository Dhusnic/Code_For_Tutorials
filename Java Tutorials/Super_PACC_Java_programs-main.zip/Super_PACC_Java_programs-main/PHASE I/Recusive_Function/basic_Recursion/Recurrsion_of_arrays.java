
public class Recurrsion_of_arrays {
    public static void main(String[] args) {

    }
}
