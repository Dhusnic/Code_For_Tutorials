## R CMD check results

0 errors | 0 warnings | 0 notes

* Includes R CMD check --as-cran

## Test environments

* Local R installation, R 4.1.2 and 4.2.0
* r-hub: Windows Server 2022, R-oldrel, 32/64 bit
* win-builder: using R version 4.2.1 (2022-06-23 ucrt) using platform: x86_64-w64-mingw32 (64-bit)

* Updated using new roxygen2 version to update documentation to HTML5
