import NavList from "./NavList";

export default function NavBar() {
    return(
        <>
            <NavList/>
        </>
    )
}