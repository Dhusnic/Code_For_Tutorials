#include<stdio.h>
int main()
{
    float a;
    printf("enter the feet = ");
    scanf("%f",&a);
    printf("inches =%g \n",a*12);
    return 0;

}