#include<stdio.h>
int main()
{
    int a;
    printf("input number = ");
    scanf("%d",&a);
    if(a%2==0)
    {
        printf("it is even");
    }
    else if(a=!0)
    {
        printf("it is odd");
    }

}