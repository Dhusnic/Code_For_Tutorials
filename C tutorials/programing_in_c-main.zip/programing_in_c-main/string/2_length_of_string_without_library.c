
int fun(int x,int y) 
{
  
    if(y==0) return 0;
    
    

}