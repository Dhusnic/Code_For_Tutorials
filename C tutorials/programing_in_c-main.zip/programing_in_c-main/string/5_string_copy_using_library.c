#include<stdio.h>
#include<string.h>
int main()
{
    char a[100],b[100];
    scanf("%s",a);
    strcpy(b,a);
    printf("%s",b);

}