#include<stdio.h>
#include<string.h>
int main()
{
    char a[100];
    scanf("%s",a);
    printf("%d",strlen(a));

}