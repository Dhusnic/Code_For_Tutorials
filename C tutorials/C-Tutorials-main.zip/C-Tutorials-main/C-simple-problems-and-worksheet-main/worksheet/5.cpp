 #include<stdio.h>
 #include<math.h>
 int main()
 {
    float x,fx;
    printf("value of x = %f" , x);
    scanf("%f",&x);
    fx=(x*x*x)+5*(x*x)+10*x+15;
    printf("f(x):%.4f",fx);
    return 0;
 

 }