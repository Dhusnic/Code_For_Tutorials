#include<stdio.h>
int main()
{
    int i,a[7];
    printf("enter the data of array");
    for (i = 0; i<5; i++)
    {
        scanf("%d",&a[i]);
    }
    for (i = 0; i<5; i++)
    {
        printf("%d \n",a[i]);
    }
    printf("-------------------------------------------------------------------------------\n");
    for (i = 0; i<5; i++)
    {
        printf("%d\n",a[i]);
    }
    

    }