#include<stdio.h>
int main()
{
    int i,a[7]={1,2,3,4,5,6,7};
    printf("print the data of array = ");
    for ( i = 0; i < 7; i++)
    {
        printf("%d ",a[i]);
    }
    
    
}
     