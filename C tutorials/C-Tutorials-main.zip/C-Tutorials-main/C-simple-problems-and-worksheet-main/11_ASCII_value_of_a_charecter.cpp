#include<stdio.h>
#include<math.h>
int main()
{
    int a;
    printf("enter a charecter = ");
    scanf("%c",&a);
    printf("the ACII value of %c is %d",a,a);
    return 0;
    
    
}
 