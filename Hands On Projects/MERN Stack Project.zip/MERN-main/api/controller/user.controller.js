export const test=(req,res)=>{
    res.json({message:'Api is Working'});
};