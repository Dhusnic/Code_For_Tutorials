import React from 'react'
import Header from '../components/Header'

export default function Profile() {
  return (
    <>
    <Header />
    <div>Profile</div>
    </>
  )
}
